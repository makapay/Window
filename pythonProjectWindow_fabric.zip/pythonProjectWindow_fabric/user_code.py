import sys
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QListWidget, QDialog, QMessageBox, QApplication, QMainWindow
from db import Qwsql
from auto import Auto_Form
from adm import adm_Form
from admin_code import Admin
from user import  us_Form

class User(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.ui = us_Form()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.back)
        self.ui.pushButton_2.clicked.connect(self.order_window)

        self.db = Qwsql()
        self.cursor = self.db.get_cursor()

        self.load_materials()
        self.load_proizv()
        self.load_op()
        self.load_par()
        self.load_komp()


    def load_materials(self):
        try:
            self.cursor.execute("SELECT title FROM materials")  # Замените на ваш запрос
            materials = self.cursor.fetchall()
            for material in materials:
                self.ui.materialBox.addItem(material[0])  # Добавляем материал в ComboBox
        except Exception as e:
            print(f"Ошибка загрузки материалов: {e}")

    def load_proizv(self):
        try:
            self.cursor.execute("select title from proizvoditeli")
            proizv = self.cursor.fetchall()
            for i in proizv:
                self.ui.proizBox.addItem(i[0])
        except Exception as e:
            print(f"Ошибка загрузки производтелей:{e}")

    def load_op(self):
        try:
            self.cursor.execute("select type from opening_type")
            types = self.cursor.fetchall()
            for i in types:
                self.ui.openBox.addItem(i[0])
        except Exception as e:
            print(f"Ошибка загрузки типов открытия: {e}")

    def load_komp(self):
        try:
            self.cursor.execute("select title from dop_complects")
            comp = self.cursor.fetchall()
            for i in comp:
                self.ui.kompBox.addItem(i[0])
        except Exception as e:
            print(f"Ошибка заргузки доп комплектации: {e}")

    def load_par(self):
        try:
            self.cursor.execute("select title from dop_parametrs")
            par = self.cursor.fetchall()
            for i in par:
                self.ui.parBox.addItem(i[0])
        except Exception as e:
            print(f"Ошибка загрузки доп параметров: {e}")

    def order_window(self):
        # Получаем данные из ComboBox и LineEdit
        material = self.ui.materialBox.currentText()
        self.cursor.execute(f"select id from materials where title = {material}")
        m_id = self.cursor.fetchone()[0]
        producer = self.ui.proizBox.currentText()
        self.cursor.execute(f"select id from proizvoditeli where title = {producer}")
        pr_id = self.cursor.fetchone()[0]
        width = self.ui.Width.text()
        length = self.ui.Length.text()
        opening_type = self.ui.openBox.currentText()
        self.cursor.execute(f"select id from opening_type where type = {opening_type} ")
        op_id = self.cursor.fetchone()[0]
        additional_comp = self.ui.kompBox.currentText()
        self.cursor.execute(f"select id from dop_complects where tutle = {additional_comp}")
        komp_id = self.cursor.fetchone()[0]
        additional_param = self.ui.parBox.currentText()
        self.cursor.execute(f"select id from dop_parametrs where title = {additional_param}")
        par_id = self.cursor.fetchone()[0]


        if not (material and producer and width and length and opening_type):
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, заполните все обязательные поля.")
            return

        try:

            self.cursor.execute("""
                        INSERT INTO windows (material_id, proizv_id, width, length, opening_type_id, dop_comp_id, dop_par_id)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """, (m_id, pr_id, width, length, op_id, komp_id, par_id))

            self.db.conn.commit()  # Коммитим изменения
            QMessageBox.information(self, "Успех", "Заказ успешно оформлен!")
            #self.clear_fields()  # Очищаем поля после успешного заказа

        except Exception as e:
            print(f"Ошибка при оформлении заказа: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось оформить заказ.")




    def back(self):
        self.close()