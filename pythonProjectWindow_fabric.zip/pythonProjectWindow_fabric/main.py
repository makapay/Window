import sys
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QListWidget, QDialog, QMessageBox, QApplication, QMainWindow
from db import Qwsql
from auto import Auto_Form
from adm import adm_Form
from admin_code import Admin
from user import us_Form
from user_code import User

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Auto_Form()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.autoriz)

        self.db = Qwsql()
        self.cursor = self.db.get_cursor()

    def autoriz(self):
        login = self.ui.lineEdit.text()
        passw = self.ui.lineEdit_2.text()
        self.cursor.execute("select login, password, role from users")
        data = self.cursor.fetchall()
        for i in data:
            try:
                if i[0] == login and i[1] == passw and i[2] == 'admin':
                    self.op_adm()
                    print("Вы вошли как администратор")
                elif i[0] == login and i[1] == passw and i[2] == 'user':
                    self.op_user()
                    print("Вы вошли как пользователь")

                #else:
                    #print("Неверный логин или пароль")

            except Exception as e:
                print(f"Ошибка авторизации: {e}")


    def op_adm(self):
        self.adm_window = Admin()
        self.adm_window.show()

    def op_user(self):
        self.user_window = User()
        self.user_window.show()









if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = Main()
    main_window.show()
    sys.exit(app.exec())