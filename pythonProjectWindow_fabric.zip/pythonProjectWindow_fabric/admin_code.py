import sys
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QListWidget, QDialog, QMessageBox, QApplication, QMainWindow
from db import Qwsql
from auto import Auto_Form
from adm import adm_Form

class Admin(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.ui = adm_Form()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.back)



    def back(self):
        self.close()