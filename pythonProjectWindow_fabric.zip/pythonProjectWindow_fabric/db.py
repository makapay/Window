import MySQLdb as mdb

class Qwsql():
    def __init__(self):

        try:
            self.conn = mdb.connect('localhost', 'root', '', 'Window_fabric')
        except mdb.Error as e:
            print(f"Ошибка подключения к бд: {e}")

    def get_cursor(self):
        return self.conn.cursor()